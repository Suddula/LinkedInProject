export class Student{
    public RollNumber: number=0;
    public Name : string="";
    public IQ : number=0;

}

