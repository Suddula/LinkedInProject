import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-linkedin-profile',
  templateUrl: './linkedin-profile.component.html',
  styleUrls: ['./linkedin-profile.component.css']
})
export class LinkedinProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
